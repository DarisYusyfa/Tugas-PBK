<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentsController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('layout.home');
});
Route::get('/home', function () {
    return view('layout.home');
});
Route::get('/students/add', function () {
    return view('students.formadd');
});
Route::put('/students/{idstudents}', [StudentsController::class, 'update']);

Route::resource('students',StudentsController::class);