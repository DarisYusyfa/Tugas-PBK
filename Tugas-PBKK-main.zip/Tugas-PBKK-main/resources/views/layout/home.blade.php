@extends('layout.main')

@section('content')
<div class="card">
    <div class="card-header">
     Welcome
    </div>
    <div class="card-body">
   <div class="alert alert-info">Selamat Datang di Projek Pertama</div>
    </div>
  </div>
  @endsection